package com.app.retrofitimplementaionexample.interfaces

interface EventClickListner {
      fun  onClickListner(position:Int)
}