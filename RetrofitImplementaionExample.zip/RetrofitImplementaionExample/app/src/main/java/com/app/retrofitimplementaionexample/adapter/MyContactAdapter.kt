package com.app.retrofitimplementaionexample.adapter

import android.content.Context
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.app.retrofitimplementaionexample.R
import com.app.retrofitimplementaionexample.interfaces.EventClickListner
import com.app.retrofitimplementaionexample.model.Contact
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.list_item_layout.view.*

class MyContactAdapter(var context: Context, var items: ArrayList<Contact>, var itemclickListner: EventClickListner) :
    RecyclerView.Adapter<MyContactAdapter.MyViewHolder>() {

     inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        // Holds the TextView that will add each animal to
        val txtName = itemView.txtId
        var txtEmail = itemView.txtEmail
        var imgProfilePic = itemView.imgProfilePic
        init {
            itemView.setOnClickListener(this)
        }
        override fun onClick(v: View?) {
            var position = adapterPosition
            itemclickListner.onClickListner(position)
        }

    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): MyViewHolder {
        return MyViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item_layout, p0, false))
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(p0: MyViewHolder, p1: Int) {
        val contact = items.get(p1)
        p0.txtName.text = contact.name
        p0.txtEmail.text = contact.email
        Glide.with(context)
            .load(Uri.parse(contact.profile_pic))
            .into(p0.imgProfilePic);

    }

}

