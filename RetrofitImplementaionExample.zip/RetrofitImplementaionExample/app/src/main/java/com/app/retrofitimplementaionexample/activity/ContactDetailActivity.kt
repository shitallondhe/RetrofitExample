package com.app.retrofitimplementaionexample.activity

import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.app.retrofitimplementaionexample.R
import com.app.retrofitimplementaionexample.model.Contact

import com.app.retrofitimplementaionexample.model.ContactModel
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_contact_detail.*
import kotlinx.android.synthetic.main.activity_contact_detail.view.*

class ContactDetailActivity : AppCompatActivity() {
    var position: Int = 0
    var contactArrayList = ArrayList<Contact>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contact_detail)
        var intent = intent
        position = intent.getIntExtra("position", 0);
        contactArrayList = intent.getParcelableArrayListExtra("list")
        Log.e("contactList on Detail",contactArrayList.toString())
        for (i in 0..contactArrayList.size-1){
            var model=contactArrayList.get(position)
            txtId.text = model.id
            txtName.text = model.name
            txtEmail.text = model.email
            txtAddress.text = model.address
            txtGender.text = model.gender
            Glide.with(this)
                .load(Uri.parse(model.profile_pic))
                .into(imgProfilePic);



        }

    }
}
