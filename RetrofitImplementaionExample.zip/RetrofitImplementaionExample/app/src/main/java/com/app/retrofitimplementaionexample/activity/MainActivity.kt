package com.app.retrofitimplementaionexample.activity

import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import com.app.retrofitimplementaionexample.R
import com.app.retrofitimplementaionexample.adapter.MyContactAdapter
import com.app.retrofitimplementaionexample.interfaces.EventClickListner
import com.app.retrofitimplementaionexample.model.*
import com.app.retrofitimplementaionexample.retofitclasses.ApiClient
import com.app.retrofitimplementaionexample.retofitclasses.ApiInterface
import com.app.retrofitimplementaionexample.util.MyDividerItemDecoration
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity(), EventClickListner {


    var contactArrayList: ArrayList<Contact> = ArrayList()
    lateinit var mAdapter: MyContactAdapter
    lateinit var clickListner: EventClickListner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clickListner = this
        prepareMovieData()
    }

    private fun prepareMovieData() {

        val apiService = ApiClient.getClient()?.create(ApiInterface::class.java)
        val call = apiService?.myJSON
        call?.enqueue(object : Callback<ContactModel> {


            override fun onResponse(call: Call<ContactModel>?, response: Response<ContactModel>) {
                contactArrayList = response.body().contacts
                Log.e("Number of movies", contactArrayList.toString())


                mAdapter = MyContactAdapter(this@MainActivity, contactArrayList, clickListner)
                val mLayoutManager = LinearLayoutManager(applicationContext)
                recyclerview.addItemDecoration(MyDividerItemDecoration(this@MainActivity, LinearLayoutManager.VERTICAL, 16))
                recyclerview.setLayoutManager(mLayoutManager)
                recyclerview.setItemAnimator(DefaultItemAnimator())
                recyclerview.setAdapter(mAdapter)

            }

            override fun onFailure(call: Call<ContactModel>?, t: Throwable?) {
                t?.printStackTrace()
                Log.e("qwqeqqrtq", t?.printStackTrace().toString())
            }
        })
    }


    override fun onClickListner(position: Int) {
        var intent = Intent(this@MainActivity,ContactDetailActivity::class.java)
        intent.putExtra("position",position)
        intent.putParcelableArrayListExtra("list",contactArrayList)
        startActivity(intent)

    }
}
