package com.app.retrofitimplementaionexample.model
import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class ContactModel(
    var contacts: ArrayList<Contact>
)

data class Contact(
    var address: String,
    var email: String,
    var gender: String,
    var id: String,
    var name: String,
    var phone: Phone,
    var profile_pic: String
) : Parcelable {
    constructor(source: Parcel) : this(
        source.readString(),
        source.readString(),
        source.readString(),
        source.readString(),
        source.readString(),
        source.readParcelable<Phone>(Phone::class.java.classLoader),
        source.readString()
    )

    override fun describeContents() = 0

    override fun writeToParcel(dest: Parcel, flags: Int) = with(dest) {
        writeString(address)
        writeString(email)
        writeString(gender)
        writeString(id)
        writeString(name)
        writeParcelable(phone, 0)
        writeString(profile_pic)
    }

    companion object {
        @JvmField
        val CREATOR: Parcelable.Creator<Contact> = object : Parcelable.Creator<Contact> {
            override fun createFromParcel(source: Parcel): Contact = Contact(source)
            override fun newArray(size: Int): Array<Contact?> = arrayOfNulls(size)
        }
    }
}

data class Phone(
    var home: String,
    var mobile: String,
    var office: String
) : Parcelable {
    constructor(source: Parcel) : this(
        source.readString(),
        source.readString(),
        source.readString()
    )

    override fun describeContents() = 0

    override fun writeToParcel(dest: Parcel, flags: Int) = with(dest) {
        writeString(home)
        writeString(mobile)
        writeString(office)
    }

    companion object {
        @JvmField
        val CREATOR: Parcelable.Creator<Phone> = object : Parcelable.Creator<Phone> {
            override fun createFromParcel(source: Parcel): Phone = Phone(source)
            override fun newArray(size: Int): Array<Phone?> = arrayOfNulls(size)
        }
    }
}