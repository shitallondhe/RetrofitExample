package com.app.retrofitimplementaionexample.retofitclasses

import com.app.retrofitimplementaionexample.model.Contact
import com.app.retrofitimplementaionexample.model.ContactModel
import retrofit2.Call
import retrofit2.http.GET


interface ApiInterface {

    /*
    Retrofit get annotation with our URL
    And our method that will return us the List of ContactList
    */
    @get:GET("/json_data.json")
    val myJSON: Call<ContactModel>
}